def salaryDeduction(SSS, Philhealth, otherLoan, tax):
    return SSS + Philhealth + otherLoan + tax