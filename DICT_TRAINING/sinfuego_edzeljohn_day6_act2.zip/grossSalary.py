def gross(RatePerHour, hour):
    return RatePerHour * hour
