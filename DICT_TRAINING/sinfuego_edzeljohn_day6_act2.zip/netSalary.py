def netSalary(grossSalary, totalDeductions):
    return grossSalary - totalDeductions